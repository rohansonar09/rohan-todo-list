import React from "react";
import SingleTodoStyled from "../styles/SingleTodoStyled";
import { MdDeleteOutline } from "react-icons/md";

const SingleTodo = ({ todo, _id }) => {
  const handleClick = () => {
    fetch(`http://localhost:4000/api/deletetodo/${_id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => res.json())
      .then((res) => console.log(res))
      .catch((err) => console.log(err));
  };
  return (
    <SingleTodoStyled>
      {todo}{" "}
      <MdDeleteOutline
        color="#fff"
        size="2rem"
        onClick={handleClick}
      ></MdDeleteOutline>
    </SingleTodoStyled>
  );
};

export default SingleTodo;
