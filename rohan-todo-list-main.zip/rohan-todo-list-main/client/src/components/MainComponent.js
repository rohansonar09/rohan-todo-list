import React, { useEffect, useRef, useState } from "react";
import { BsFillPlusSquareFill } from "react-icons/bs";
import MainStyled from "../styles/MainStyled";
import SingleTodo from "./SingleTodo";

const MainComponent = () => {
  const inputEl = useRef(null);
  const [allTodos, setAllTodos] = useState([]);
  const [first, setfirst] = useState(true);

  const handleNewTodo = () => {
    let todoValue = inputEl.current.value;
    if (todoValue !== "") {
      fetch("http://localhost:4000/api/create", {
        method: "POST",
        body: JSON.stringify({ todo: todoValue }),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((res) => res.json())
        .then((res) => setfirst(!first))
        .catch((err) => console.log(err));
    }
  };

  useEffect(() => {
    fetch("http://localhost:4000/api/todos")
      .then((res) => res.json())
      .then((res) => setAllTodos(res.data))
      .catch((err) => console.log(err));
  }, [first]);

  return (
    <MainStyled>
      <header>
        <h1>Todo App</h1>
      </header>
      <div className="todo-input">
        <input type="text" placeholder="Enter a new Todo" ref={inputEl}></input>
        <BsFillPlusSquareFill
          color="#8E49E8"
          size="3rem"
          onClick={handleNewTodo}
        ></BsFillPlusSquareFill>
      </div>
      <ul className="todo-list">
        {allTodos.map((eachTodo, i) => (
          <SingleTodo key={i} {...eachTodo} first={setfirst}></SingleTodo>
        ))}
      </ul>
      <footer>
        <p>
          You have <span className="pending">{allTodos.length}</span> pending
          Todos
        </p>
        {/* <button>Clear</button> */}
      </footer>
    </MainStyled>
  );
};

export default MainComponent;
