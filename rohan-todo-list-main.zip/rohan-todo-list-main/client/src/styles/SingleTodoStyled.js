import styled from "styled-components";

const SingleTodoStyled = styled.li`
  width: 100%;
  margin-bottom: 8px;
  background: #f2f2f2;
  border-radius: 3px;
  display: flex;
  align-items: center;
  padding-left: 10px;
  justify-content: space-between;
  padding-top: 5px;
  padding-bottom: 5px;
  font-size: 1.2rem;

  svg {
    background-color: #8e49e8;
    height: 100%;
    cursor: pointer;
  }
`;

export default SingleTodoStyled;
