import styled from "styled-components";

const MainStyled = styled.main`
  background: #fff;
  max-width: 400px;
  width: 85%;
  padding: 25px;
  border-radius: 5px;
  box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: center;

  header {
    align-self: flex-start;
  }

  .todo-input {
    margin: 20px 0;
    width: 100%;
    display: flex;
    height: 45px;
    gap: 0.5rem;

    input {
      width: 85%;
      outline: none;
      border-radius: 5px;
      border: 1px solid #ccc;
      font-size: 17px;
      padding-left: 15px;
      transition: all 0.3s ease;
    }
    input:focus {
      border-color: #8e49e8;
    }

    svg {
      cursor: pointer;
    }
  }

  .todo-list {
    list-style: none;
    width: 100%;
  }

  footer {
    display: flex;
    width: 100%;
    margin-top: 20px;
    align-items: center;
    justify-content: center;

    p {
      width: 100%;
      /* font-size: 0.9rem; */
    }

    button {
      padding: 6px 10px;
      border-radius: 3px;
      border: none;
      outline: none;
      color: #fff;
      font-weight: 400;
      font-size: 16px;
      margin-left: 5px;
      background: #8e49e8;
      cursor: pointer;
      opacity: 0.6;
      transition: all 0.3s ease;
    }
  }
`;

export default MainStyled;
