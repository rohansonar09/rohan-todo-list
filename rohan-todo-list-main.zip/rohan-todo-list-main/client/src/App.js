import { ThemeProvider } from "styled-components";
import MainComponent from "./components/MainComponent";
import GlobalStyled from "./styles/Global";
import theme from "./styles/theme";

function App() {
  return (
    <ThemeProvider theme={theme}>
      <GlobalStyled></GlobalStyled>
      <MainComponent></MainComponent>
    </ThemeProvider>
  );
}

export default App;
