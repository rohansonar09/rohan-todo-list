const express = require("express");
const morgan = require("morgan");
const app = express();
const PORT = process.env.PORT || 4000;
const mongoose = require("mongoose");
const { config } = require("dotenv");
config();
const corsOption = require("./utils/corsOption");

app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(corsOption);

app.get("/", (req, res) => {
  return res.send("Rohan TOdo-List API running");
});
app.use("/api", require("./routes/todoRoutes"));

mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then((res) => console.log("Successfully connected to the database"))
  .catch((err) => console.log("Error connecting to database"));

app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
